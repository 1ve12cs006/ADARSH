package com.niit.shopping;

public class Product {
private int id;
private String name;
private int price;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public void setName(String name) {
	this.name = name;
}
public Product(int id, String name) {
	super();
	this.id = id;
	this.name = name;
}

}
