package com.niit.shopping;

public class TestProduct {
	public static void main(String[] args) {
		Product p1=new Product(0, null);
		p1.setId(101);
		p1.setName("iphone");
		p1.setPrice(60000);
		System.out.println("ID:"+p1.getId());
	System.out.println("name:"+p1.getName());
	System.out.println("price:"+p1.getPrice());
	}
	

}
